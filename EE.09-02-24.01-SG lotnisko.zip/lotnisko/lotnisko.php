<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Port Lotniczy</title>
    <link rel="stylesheet" href="styl5.css">
</head>
<body>
<div class="baner">
    <div class="baner1"><img src="zad5.png" alt="logo lotnisko"></div>
    <div class="baner2"><h1>Przyloty</h1></div>
    <div class="baner3"><h3>przydatne linki</h3>
        <a href="kwerendy.txt">Pobierz...</a>
    </div>
</div>
<main>
    <table>
        <tr>
            <th>czas</th>
            <th>kierunek</th>
            <th>numer rejsu</th>
            <th>status</th>
        </tr>
        <?php
            $conn = mysqli_connect("localhost", "root", "", "egzamin");
            $kw = "SELECT `czas`, `kierunek`, `nr_rejsu`, `status_lotu` FROM `przyloty` ORDER BY `czas` ASC;";
            $q = mysqli_query($conn, $kw);

            while($row = mysqli_fetch_array($q)){
                echo "<tr>
                    <td>$row[0]</td>
                    <td>$row[1]</td>
                    <td>$row[2]</td>
                    <td>$row[3]</td>
                </tr>";
            }
        ?>
    </table>
</main>
<footer>
    <div class="stopka1">
        <?php
            if(isset($_COOKIE['stronaOdwiedzona'])) {
                echo "<p><i>Witaj ponownie na stronie lotniska!</i></p>";
            }
            else {
                echo "<p><b>Dzień dobry! Strona lotniska używa ciasteczek.</b></p>";
                setcookie("stronaOdwiedzona", "true", time() + 7200);
            }
        ?>
    </div>
    <div class="stopka2">
        Autor: Wiola
    </div>
</footer>
</body>
</html>