<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Zadania na lipiec</title>
    <link rel="stylesheet" href="styl6.css">
</head>
<body>
<header>
    <div class="banner1">
        <img src="logo1.png" alt="lipiec">
    </div>
    <div class="banner2">
        <h1>TERMINARZ</h1>
        <p>najbliższe zadania: 
            <?php
                $conn = mysqli_connect("localhost", "root", "", "terminarz");
                $kw = "SELECT DISTINCT `wpis` FROM `zadania` WHERE `dataZadania` BETWEEN '2020-07-01' AND '2020-07-07' AND `wpis`!='';";
                $q = mysqli_query($conn, $kw);

                while($row = mysqli_fetch_row($q)){
                    echo "$row[0]; ";
                }
            ?>
        </p>
    </div>
</header>
<main>
<?php
    $kw2 = "SELECT `dataZadania`, `wpis` FROM `zadania` WHERE `miesiac` LIKE 'lipiec';";
    $q2 = mysqli_query($conn, $kw2);
    while($row = mysqli_fetch_array($q2)) {
        echo "<div>";
        echo "<h6>$row[0]</h6>";
        echo "<p>$row[1]</p>";
        echo "</div>";
    }
?>
</main>
<footer>
<a href="sierpien.html">Terminarz na sierpień</a>
<p>Stronę wykonał: Wiola</p>
</footer>
</body>
</html>