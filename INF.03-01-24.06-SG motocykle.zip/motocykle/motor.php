<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Motocykle</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <img src="motor.png" alt="motocykl" id="motor">
    <div class="baner">
        <h1>Motocykle - moja pasja</h1>
    </div>
    <div class="lewy">
        <h2>Gdzie pojechać?</h2>
        <?php
            $conn = mysqli_connect("localhost", "root", "", "motory");
            $kw = "SELECT nazwa, opis, poczatek, zrodlo FROM wycieczki JOIN zdjecia ON zdjecia_id = zdjecia.id;";
            $q = mysqli_query($conn, $kw);

            while($row  = mysqli_fetch_array($q)){
                echo "
                <dl>
                    <dt>$row[0], rozpoczyna się w $row[2] <a href='$row[3].jpg' >zobacz zdjęcie</a></dt>
                    <dd>$row[1]</dd>
                </dl>
                ";
            }

        ?>
    </div>
    <div class="prawy1">
        <h2>Co kupić?</h2>
        <ol>
            <li>Honda CBR125R</li>
            <li>Yamaha YBR125</li>
            <li>Honda VFR800i</li>
            <li>Honda CBR1100XX</li>
            <li>BMW R1200GS LC</li>
        </ol>
    </div>
    <div class="prawy2">
        <h2>Statystyki</h2>
            <?php
            $kw2 = "SELECT COUNT(*) FROM wycieczki;";
            $q2 = mysqli_query($conn, $kw2);

            while($row = mysqli_fetch_array($q2)){
                echo "<p>Wpisanych wycieczek: $row[0]</p>";
            }

            $conn -> close();
            ?>
        <p>Użytkowników forum: 200</p>
        <p>Przesłanych zdjęć: 1300</p>
    </div>
    <div class="stopka">
        <p>Stronę wykonał: Wiola</p>
    </div>
</body>
</html>